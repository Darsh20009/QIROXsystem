# QIROX — iOS App (Capacitor)

## المتطلبات
- Mac مع macOS 13+
- Xcode 15+
- CocoaPods
- Node.js 20+
- حساب Apple Developer ($99/سنة)

## خطوات البناء

### 1. تثبيت المتطلبات
```bash
npm install
npx cap sync
```

### 2. تثبيت CocoaPods
```bash
cd ios/QIROX && pod install
```

### 3. فتح في Xcode
```bash
npx cap open ios
```

### 4. الإعدادات في Xcode
- Signing & Capabilities → اختر Team والـ Bundle ID: com.qirox.studio
- Product → Archive

### 5. الرفع على App Store Connect
- Organizer → Distribute App → App Store Connect → Upload

## ملاحظات
- الرابط: https://qiroxstudio.online
- الإصدار: 1.0.0
- تاريخ التوليد: ٩‏/٤‏/٢٠٢٦ ٢:٢٢:٢١ م
